/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/

public class Main
{
	public static void main(String[] args) {
	int age = 18;
	if (age >= 18) {
	    System.out.println("Поздравление с совершеннолетием");
	}
	if (age < 18) {
	    System.out.println("Возраст совершеннолетия ещё не наступил, нужно немного подождать");
	}
	if (age >= 7){
	    System.out.println("Ребёнок ходит в школу");
	}
	if (age >= 18) {
	    System.out.println("Человек уже закончил школу и может отправляться в университет");
	}
	if (age >= 24) {
	    System.out.println("Человек окончил университет и ему пора искать первую работу");
	}
	int numberOfPassengers = 102;
	int availablePlaces = 102;
	int seatingPlaces = 60;
	int standingPlaces = availablePlaces - seatingPlaces;
	if (numberOfPassengers < 60) {
	    System.out.println("Есть и сидячие, и стоячие места");
	}
	if ((numberOfPassengers > 60) && (numberOfPassengers < 102)) {
	    System.out.println("Сидячие места заняты, но есть стоячие");
	}
	if (numberOfPassengers >= 102) {
	    System.out.println("Мест нет, вагон уже полностью забит");
	}
	age = 18;
	if (age >= 18) {
	    System.out.println("Поздравление с совершеннолетием");
	} else {
	    System.out.println("Возраст совершеннолетия ещё не наступил, нужно немного подождать");
	}
	if (age >= 7){
	    System.out.println("Ребёнок ходит в школу");
	} else {
	    System.out.println("Ребёнок не ходит в школу");
	}
	
	
	}
}
